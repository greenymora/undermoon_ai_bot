/**
 * @file        program-exit.js
 *              Support code program-exit.bash
 * @author      Wes Garland, wes@distributive.network
 * @date        July 2023
 */
setTimeout(()=>console.log('hey'), 10400)
python.exit(99)

/**
 * @file        timers-natural-exit.js
 *              Support code timers-natural-exit.bash
 * @author      Wes Garland, wes@distributive.network
 * @date        July 2023
 */

setTimeout(()=>console.log('fired timer'), 500);
console.log('end of program')

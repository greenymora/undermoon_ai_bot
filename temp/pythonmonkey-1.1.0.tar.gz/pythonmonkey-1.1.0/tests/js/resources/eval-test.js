console.log('eval-test.js loaded from', __filename);
18436572;
